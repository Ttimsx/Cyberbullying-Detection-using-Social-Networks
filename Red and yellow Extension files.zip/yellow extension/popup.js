document
.getElementById('testBtn')
.addEventListener('click', () => {

  const status =
    document.getElementById('status');

  status.innerText = "Sending...";

  chrome.runtime.sendMessage({

    action: "send_alert_yellow",
    content:
      "TEST alert from Yellow system",
    trigger: "TEST_MODE"

  }, () => {

    status.innerText =
      "Check your email!";

    setTimeout(() => {

      status.innerText = "";

    }, 3000);

  });

});