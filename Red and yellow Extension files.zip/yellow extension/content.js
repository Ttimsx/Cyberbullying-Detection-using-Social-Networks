console.log("BullyGuard Yellow: Content Script Loaded");

let yellowTerms = new Set();

async function initializeDataset() {
  try {
    const csvUrl = chrome.runtime.getURL('yellow.csv');
    const response = await fetch(csvUrl);
    const csvData = await response.text();

    const lines = csvData.split(/\r?\n/);

    lines.forEach((line, index) => {
      if (index === 0 || !line.trim()) return;

      const parts = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);

      if (parts.length >= 2) {
        const text = parts[0].replace(/"/g, '').trim().toLowerCase();
        const label = parts[1].trim();

        if (label === "1") yellowTerms.add(text);
      }
    });

    console.log("Yellow Loaded:", yellowTerms.size);

    startMonitoring();

  } catch (err) {
    console.error("Yellow CSV Load Error:", err);
  }
}

function startMonitoring() {

  document.addEventListener('input', (event) => {

    const text =
      (event.target.value ||
       event.target.innerText ||
       "").toLowerCase();

    let found = null;

    for (let term of yellowTerms) {

      if (text.includes(term)) {
        found = term;
        break;
      }

    }

    if (found) {

      event.target.style.setProperty(
        'outline',
        '5px solid yellow',
        'important'
      );

      chrome.runtime.sendMessage({
        action: "send_alert_yellow",
        content: text,
        trigger: found
      });

    }

  });

}

initializeDataset();