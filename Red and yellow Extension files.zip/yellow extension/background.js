console.log("BullyGuard Yellow: Background Active");

chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {

    if (request.action === "send_alert_yellow") {

      console.log(
        "Yellow Alert:",
        request.trigger
      );

      sendEmail(
        request.content,
        request.trigger
      );

      sendResponse({
        status: "yellow_sent"
      });

    }

    return true;
  }
);

async function sendEmail(content, trigger) {

  const payload = {

    service_id: 'service_zs85rzl',
    template_id: 'template_x7q635o',
    user_id: 'Dm-ajc4oTaiYLB_nh',

    template_params: {
      message: content,
      flagged_word: trigger,
      time: new Date().toLocaleString()
    }

  };

  try {

    const response = await fetch(
      'https://api.emailjs.com/api/v1.0/email/send',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      }
    );

    if (response.ok)
      console.log("Yellow Email Sent");

    else
      console.log(
        "Yellow EmailJS Error",
        await response.text()
      );

  }
  catch (e) {

    console.error(
      "Yellow Network Error",
      e
    );

  }

}