document.getElementById('testBtn').addEventListener('click', () => {
  const status = document.getElementById('status');
  status.innerText = "Sending...";

  // Send a fake alert to the background script
  chrome.runtime.sendMessage({
    action: "send_alert",
    content: "This is a TEST alert from the BullyGuard popup. Your system is working!",
    trigger: "TEST_MODE"
  }, (response) => {
    status.innerText = "Check your email!";
    setTimeout(() => { status.innerText = ""; }, 3000);
  });
});