console.log("BullyGuard Red: Background Active");

chrome.runtime.onMessage.addListener(
  (request, sender, sendResponse) => {

    if (request.action === "send_alert_red") {

      console.log(
        "Red Alert:",
        request.trigger
      );

      sendEmail(
        request.content,
        request.trigger
      );

      sendResponse({
        status: "red_sent"
      });

    }

    return true;

  }
);

async function sendEmail(content, trigger) {

  const payload = {

    service_id: 'service_zegoa4r',
    template_id: 'template_6motaje',
    user_id: 'Dm-ajc4oTaiYLB_nh',

    template_params: {

      message: content,
      flagged_word: trigger,
      time:
        new Date().toLocaleString()

    }

  };

  try {

    const response =
      await fetch(
        'https://api.emailjs.com/api/v1.0/email/send',
        {
          method: 'POST',
          headers: {
            'Content-Type':
              'application/json'
          },
          body: JSON.stringify(payload)
        }
      );

    if (response.ok)
      console.log("Red Email Sent");

    else
      console.log(
        "Red EmailJS Error",
        await response.text()
      );

  }

  catch (e) {

    console.error(
      "Red Network Error",
      e
    );

  }

}